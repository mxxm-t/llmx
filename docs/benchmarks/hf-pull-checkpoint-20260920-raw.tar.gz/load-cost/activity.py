import json
import math


def read_log(path, complete=True):
    raw = path.read_bytes()
    lines = raw.splitlines()
    if not complete and raw and not raw.endswith(b'\n'):
        lines = lines[:-1]
    return [json.loads(line) for line in lines]


def assess(rows, begin, end, benchmark=None, complete=True):
    flags, summaries = [], []
    def flag(reason):
        if reason not in flags:
            flags.append(reason)
    metadata = [r for r in rows if r.get('kind') == 'metadata']
    if len(metadata) != 1:
        return {'status': 'inconclusive', 'flags': ['missing unique metadata'], 'samples': []}
    meta = metadata[0]
    if meta.get('unavailable'):
        flag('unavailable providers')
    if complete and (not rows or rows[-1].get('kind') != 'end'):
        flag('missing terminal record')
    samples = [r for r in rows if r.get('kind') == 'sample' and
               r['counter_interval_start_bracket'][0] <= end and
               r['counter_interval_end_bracket'][1] >= begin]
    if not samples:
        flag('no overlapping activity samples')
    elif (samples[0]['counter_interval_start_bracket'][1] > begin or
          samples[-1]['counter_interval_end_bracket'][0] < end):
        flag('activity samples do not cover complete interval')
    streak = {}
    def consecutive(key, test):
        streak[key] = streak.get(key, 0) + 1 if test else 0
        if streak[key] >= 2:
            flag(key)
    previous_end = None
    for sample in samples:
        first = sample['counter_interval_start_bracket'][0]
        last = sample['counter_interval_end_bracket'][1]
        if last - first > 2.5 or (previous_end is not None and first - previous_end > 2.5):
            flag('activity gap exceeds 2.5 seconds')
        previous_end = last
        if sample.get('collect_status'):
            flag('counter collection failed')
        def values(name):
            counter = sample.get('counters', {}).get(name, {})
            items = counter.get('items', [])
            if counter.get('error') or not items:
                flag('missing or failed ' + name)
            result = {}
            for item in items:
                value = item.get('value')
                if item.get('status') not in (0, 1) or not isinstance(value, (int, float)) or not math.isfinite(value):
                    flag('invalid ' + name)
                elif value < 0 or (name != 'disk_bytes_per_second' and value > 100):
                    flag('out-of-range ' + name)
                elif item['name'] in result:
                    flag('duplicate instance in ' + name)
                else:
                    result[item['name']] = value
            return result
        cpu = values('cpu_percent')
        disk = values('disk_idle_percent')
        values('disk_bytes_per_second')
        gpu = values('gpu_engine_percent')
        if '_Total' not in cpu:
            flag('missing total CPU')
        actual_disks = {name: max(0, 100 - value) for name, value in disk.items() if name != '_Total'}
        if not actual_disks:
            flag('missing physical disk instances')
        processes = sample.get('processes', {})
        if processes.get('error') or not processes.get('items'):
            flag('process enumeration failed')
        unrelated, observed, observer = 0.0, 0.0, 0.0
        observer_rows = 0
        unknown, excluded, busy = [], [], []
        for process in processes.get('items', []):
            identity = [process['pid'], process.get('created_filetime')]
            known_jobs = {'cl.exe', 'link.exe', 'msbuild.exe', 'ninja.exe', 'cmake.exe',
                          'llmx.exe', 'llama-bench.exe', 'llama-cli.exe', 'llama-server.exe',
                          'timing-control.exe', 'timing-candidate.exe', 'mx-model.exe',
                          'control-long.exe', 'candidate-long.exe', 'witness-cli.exe'}
            value = process.get('cpu_percent')
            if value is None or not math.isfinite(value) or value < 0:
                unknown.append(process['pid'])
                continue
            if identity != benchmark and (process.get('name') or '').lower() in known_jobs and value > 1:
                flag('overlapping build or model process activity')
            observed += value
            if process['pid'] == meta['pid']:
                observer += value
                observer_rows += 1
                excluded.append({'identity': identity, 'reason': 'recorder', 'cpu': value})
            elif benchmark and identity == benchmark:
                excluded.append({'identity': identity, 'reason': 'benchmark', 'cpu': value})
            else:
                unrelated += value
                if value > 0:
                    busy.append({'identity': identity, 'name': process.get('name'), 'cpu': value})
        if observer_rows != 1:
            flag('missing unique valid recorder CPU observation')
        residual = cpu.get('_Total', 0) * meta['logical_cpus'] - observed
        if unrelated > 100:
            flag('unrelated CPU exceeds one logical CPU')
        consecutive('unrelated CPU sustained above 25 percent of one CPU', unrelated > 25)
        consecutive('unresolved CPU sustained above one logical CPU', residual > 100)
        consecutive('recorder CPU sustained above 5 percent of one CPU', observer > 5)
        consecutive('physical disk busy sustained above 20 percent', any(v > 20 for v in actual_disks.values()))
        consecutive('GPU engine sustained above 25 percent', any(v > 25 for v in gpu.values()))
        summaries.append({'start': first, 'end': last, 'unrelated_cpu_percent_one_core': unrelated,
                          'unresolved_cpu_percent_one_core': residual,
                          'recorder_cpu_percent_one_core': observer, 'disk_busy_percent': actual_disks,
                          'gpu_max_engine_percent': max(gpu.values(), default=None),
                          'unknown_process_pids': unknown, 'excluded': excluded,
                          'busy_processes': sorted(busy, key=lambda p: p['cpu'], reverse=True)})
    return {'status': 'inconclusive' if flags else 'no_declared_contention',
            'begin': begin, 'end': end, 'benchmark': benchmark, 'flags': flags,
            'samples': summaries,
            'limits': 'Sampled observations do not exclude short bursts, inaccessible processes or all observer effects.'}
