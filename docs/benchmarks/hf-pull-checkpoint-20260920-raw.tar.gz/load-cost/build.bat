@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >environment.stdout 2>environment.stderr
if errorlevel 1 exit /b 1
cl /nologo /Bv /std:c++17 /O2 /EHsc /W4 /arch:AVX2 /I "C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\control-src" /Fe:"C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\control.exe" /Fo:"C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\control.obj" "C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\load.cpp" >control-build.stdout 2>control-build.stderr
if errorlevel 1 exit /b 1
cl /nologo /Bv /std:c++17 /O2 /EHsc /W4 /arch:AVX2 /I "C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\candidate-src" /Fe:"C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\candidate.exe" /Fo:"C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\candidate.obj" "C:\Users\Marko\AppData\Local\Temp\llmx-hf-pull-20260920\load-cost\load.cpp" >candidate-build.stdout 2>candidate-build.stderr
if errorlevel 1 exit /b 1
exit /b 0
