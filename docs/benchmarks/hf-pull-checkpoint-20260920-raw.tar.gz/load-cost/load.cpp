#define NOMINMAX
#include <windows.h>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include "format/gguf.hpp"
#include "fingerprint_sha.hpp"

static void number(core::Sha& hash, uint64_t value) {
    uint8_t bytes[8];
    for (unsigned i = 0; i < 8; ++i) bytes[i] = uint8_t(value >> (i * 8));
    hash.update(bytes, sizeof(bytes));
}
static void text(core::Sha& hash, const std::string& value) {
    number(hash, value.size()); hash.update(value.data(), value.size());
}
static void metadata(core::Sha& hash, const gguf::MetaValue& value) {
    number(hash, value.vtype);
    switch (value.vtype) {
        case gguf::V_UINT8: case gguf::V_UINT16: case gguf::V_UINT32: case gguf::V_UINT64:
            number(hash, value.u); break;
        case gguf::V_INT8: case gguf::V_INT16: case gguf::V_INT32: case gguf::V_INT64:
            number(hash, uint64_t(value.i)); break;
        case gguf::V_FLOAT32: number(hash, value.fb); break;
        case gguf::V_FLOAT64: {
            uint64_t bits;
            static_assert(sizeof(bits) == sizeof(value.f64), "double size");
            std::memcpy(&bits, &value.f64, sizeof(bits)); number(hash, bits); break;
        }
        case gguf::V_BOOL: number(hash, value.b ? 1 : 0); break;
        case gguf::V_STRING: text(hash, value.s); break;
        case gguf::V_ARRAY:
            number(hash, value.u); number(hash, value.arr.size());
            for (const auto& item : value.arr) metadata(hash, item);
            break;
        default: throw std::runtime_error("unrecognized metadata type");
    }
}

int main(int argc, char** argv) {
    try {
        if (argc != 2) throw std::runtime_error("usage: load MODEL");
        LARGE_INTEGER frequency{}, begin{}, end{};
        if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0)
            throw std::runtime_error("QPC unavailable");
        FILETIME created{}, exited{}, kernel{}, user{};
        if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user))
            throw std::runtime_error("process identity unavailable");
        if (!QueryPerformanceCounter(&begin)) throw std::runtime_error("QPC start failed");
        auto model = gguf::read_gguf(argv[1]);
        if (!QueryPerformanceCounter(&end)) throw std::runtime_error("QPC end failed");

        core::Sha payload(true), descriptors(true), meta(true);
        payload.update(model.blob.data(), model.blob.size());
        if (model.offsets.size() != model.tensors.size()) throw std::runtime_error("offset count");
        number(descriptors, model.tensors.size());
        uint64_t tensor_bytes = 0;
        for (size_t i = 0; i < model.tensors.size(); ++i) {
            const auto& tensor = model.tensors[i];
            const auto bytes = tensor.data_size();
            const auto offset = model.offsets[i];
            if (offset > model.blob.size() || bytes > model.blob.size() - offset)
                throw std::runtime_error("tensor storage extent");
            tensor_bytes += bytes;
            text(descriptors, tensor.name); number(descriptors, tensor.type);
            number(descriptors, tensor.ne.size());
            for (auto dim : tensor.ne) number(descriptors, dim);
            number(descriptors, tensor.offset); number(descriptors, offset); number(descriptors, bytes);
        }
        number(meta, model.kv.size());
        for (const auto& item : model.kv) { text(meta, item.first); metadata(meta, item.second); }
        const uint64_t creation = (uint64_t(created.dwHighDateTime) << 32) | created.dwLowDateTime;
        std::cout << std::setprecision(17)
            << "{\"pid\":" << GetCurrentProcessId() << ",\"created_filetime\":" << creation
            << ",\"qpc_begin\":" << double(begin.QuadPart) / double(frequency.QuadPart)
            << ",\"qpc_end\":" << double(end.QuadPart) / double(frequency.QuadPart)
            << ",\"load_ms\":" << double(end.QuadPart - begin.QuadPart) * 1000 / double(frequency.QuadPart)
            << ",\"tensor_count\":" << model.tensors.size() << ",\"metadata_count\":" << model.kv.size()
            << ",\"blob_bytes\":" << model.blob.size() << ",\"tensor_bytes\":" << tensor_bytes
            << ",\"payload_sha256\":\"" << payload.hex()
            << "\",\"tensor_sha256\":\"" << descriptors.hex()
            << "\",\"metadata_sha256\":\"" << meta.hex() << "\"}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
