from pathlib import Path
import ctypes as ct
from ctypes import wintypes as wt
import datetime
import hashlib
import json
import math
import statistics
import subprocess
import sys
import time
from activity import assess, read_log

ROOT = Path(__file__).parent


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(child):
    fn = ct.WinDLL('kernel32', use_last_error=True).GetProcessTimes
    fn.argtypes = [wt.HANDLE] + [ct.POINTER(wt.FILETIME)] * 4
    fn.restype = wt.BOOL
    times = [wt.FILETIME() for _ in range(4)]
    if not fn(int(child._handle), *(ct.byref(t) for t in times)):
        raise ct.WinError(ct.get_last_error())
    return [child.pid, (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime]


def activity(rows, record):
    result = assess(rows, record['qpc_begin'], record['qpc_end'],
                    [record['pid'], record['created_filetime']])
    flags = result.get('flags', [])
    all_unknown = any(x in flags for x in ('unavailable providers', 'missing unique metadata'))
    processes_unknown = all_unknown or 'process enumeration failed' in flags
    recorder_unknown = all_unknown or 'missing unique valid recorder CPU observation' in flags
    residual_unknown = processes_unknown or any('cpu_percent' in x or x in
        ('counter collection failed', 'missing total CPU') for x in flags)
    for sample in result.get('samples', []):
        if processes_unknown: sample['unrelated_cpu_percent_one_core'] = None
        if recorder_unknown: sample['recorder_cpu_percent_one_core'] = None
        if residual_unknown: sample['unresolved_cpu_percent_one_core'] = None
        sample['process_cpu_scope'] = 'observed/incomplete' if sample['unknown_process_pids'] else 'observed'
    result['limits'] += (' Subsecond loader windows may have no reliable per-process CPU estimate; '
        'disk includes loader I/O and is not attributable unrelated disk. Fingerprinting outside '
        'the timer can overlap sample brackets. No timing correction or sample exclusion.')
    return result


def main():
    if not __debug__:
        raise RuntimeError('validation requires assertions enabled')
    plan = json.loads((ROOT / 'plan.json').read_text())
    frozen = json.loads((ROOT / 'manifest.json').read_text())
    output = ROOT / 'run-01'
    output.mkdir()
    state = {'status': 'preflight', 'started': now(), 'plan': plan,
             'manifest_sha256': sha(ROOT / 'manifest.json'), 'pairs': []}

    def save():
        (output / 'results.json').write_text(json.dumps(state, indent=2) + '\n')

    def verify():
        for name, digest in frozen['files'].items():
            assert sha(ROOT / name) == digest, name
        model = Path(plan['model'])
        assert model.stat().st_size == plan['model_size']
        assert sha(model) == plan['model_sha256']

    save()
    expected = None
    fingerprint_keys = ['tensor_count', 'metadata_count', 'blob_bytes', 'tensor_bytes',
                        'payload_sha256', 'tensor_sha256', 'metadata_sha256']
    try:
        verify()
        state['preflight_identity'] = 'pass'
        state['status'] = 'running'
        save()
        for scheduled in plan['schedule']:
            directory = output / ('warmup' if scheduled['warmup'] else f"pair-{scheduled['pair']}")
            directory.mkdir()
            pair = dict(scheduled, records=[], status='monitor_starting')
            state['pairs'].append(pair)
            log, stop = directory / 'activity.jsonl', directory / 'stop'
            monitor_command = [sys.executable, '-X', 'utf8', str(ROOT / 'monitor_windows.py'),
                               '--output', str(log), '--seconds', '300', '--stop-file', str(stop)]
            pair['monitor_command'] = monitor_command
            with (directory / 'monitor.stdout').open('wb') as mout, (directory / 'monitor.stderr').open('wb') as merr:
                monitor = subprocess.Popen(monitor_command, stdout=mout, stderr=merr)
                pair['monitor_pid'] = monitor.pid
                save()
                try:
                    time.sleep(11.5)
                    if monitor.poll() is not None:
                        raise RuntimeError('monitor stopped before pair')
                    for arm in scheduled['arms']:
                        command = [str(ROOT / (arm + '.exe')), plan['model']]
                        row = {'arm': arm, 'command': command, 'started': now(), 'status': 'launching'}
                        pair['records'].append(row)
                        save()
                        with (directory / (arm + '.stdout')).open('wb') as out, (directory / (arm + '.stderr')).open('wb') as err:
                            before = time.perf_counter()
                            child = subprocess.Popen(command, stdout=out, stderr=err)
                            try:
                                row['identity'] = identity(child)
                                row['status'] = 'running'
                                save()
                                code = child.wait(timeout=plan['child_timeout_seconds'])
                            finally:
                                if child.poll() is None:
                                    child.kill()
                                    row.update(status='terminated', exit_code=child.wait())
                                    save()
                        row.update(exit_code=code, finished=now(), status='validating')
                        save()
                        assert code == 0, f'{arm} exit{code}'
                        record = json.loads((directory / (arm + '.stdout')).read_text())
                        assert [record['pid'], record['created_filetime']] == row['identity']
                        assert before <= record['qpc_begin'] < record['qpc_end'] <= time.perf_counter()
                        assert math.isfinite(record['load_ms']) and record['load_ms'] > 0
                        assert abs((record['qpc_end'] - record['qpc_begin']) * 1000 - record['load_ms']) < .01
                        fingerprint = {k: record[k] for k in fingerprint_keys}
                        if expected is None: expected = fingerprint
                        assert fingerprint == expected, 'complete loaded representation fingerprint changed'
                        row.update(record=record, status='pass')
                        save()
                    time.sleep(1.5)
                finally:
                    stop.touch()
                    try:
                        pair['monitor_exit'] = monitor.wait(timeout=15)
                    finally:
                        if monitor.poll() is None:
                            monitor.kill()
                            pair['monitor_exit'] = monitor.wait()
                    save()
            assert pair['monitor_exit'] == 0
            rows = read_log(log)
            assert rows and rows[-1].get('kind') == 'end'
            for row in pair['records']:
                row['activity'] = activity(rows, row['record'])
            pair.update(status='pass', activity_sha256=sha(log))
            save()
        measured = [p for p in state['pairs'] if not p['warmup']]
        assert len(measured) == 5 and sum(len(p['records']) for p in state['pairs']) == 12
        times = {arm: [next(r['record']['load_ms'] for r in p['records'] if r['arm'] == arm)
                       for p in measured] for arm in ['control', 'candidate']}
        paired = [(a/b - 1)*100 for a,b in zip(times['control'], times['candidate'])]
        mean = statistics.mean(paired)
        half = 2.7764451051977987 * statistics.stdev(paired) / math.sqrt(5)
        state['summary'] = {'arms_ms': {arm: {'all': values, 'mean': statistics.mean(values),
            'median': statistics.median(values), 'min': min(values), 'max': max(values)} for arm,values in times.items()},
            'paired_speed_percent': {'all': paired, 'mean': mean, 'median': statistics.median(paired),
            'wins': sum(v > 0 for v in paired), 'descriptive_t95': [mean-half, mean+half]},
            'fingerprints': expected, 'scope': 'Five warm-cache loader pairs only; no inference/causal-cleanliness claim.'}
        verify()
        state.update(status='pass', postflight_identity='pass', finished=now())
        save()
        print(json.dumps(state['summary'], indent=2), flush=True)
    except BaseException as error:
        state.update(status='failed', error=repr(error), finished=now())
        save()
        raise


if __name__ == '__main__':
    main()
