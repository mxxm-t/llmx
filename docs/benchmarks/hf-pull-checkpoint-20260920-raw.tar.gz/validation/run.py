import json
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
record = {"name": name, "command": command, "started": time.time(), "status": "running"}
report = root / (name + ".json")
report.write_text(json.dumps(record, indent=2))
with (root / (name + ".log")).open("w", encoding="utf-8") as output:
    process = subprocess.Popen(command, cwd="C:/Users/Marko/Desktop/Projects/llmx-runtime", stdout=output, stderr=subprocess.STDOUT)
    record["pid"] = process.pid
    report.write_text(json.dumps(record, indent=2))
    code = process.wait()
record.update(status="completed", code=code, seconds=time.time()-record["started"])
report.write_text(json.dumps(record, indent=2))
print(json.dumps(record), flush=True)
print("\n".join((root / (name + ".log")).read_text(encoding="utf-8", errors="replace").splitlines()[-18:]), flush=True)
sys.exit(code)
